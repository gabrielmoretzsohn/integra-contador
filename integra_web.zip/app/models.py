from flask_login import UserMixin
from datetime import datetime
from . import db


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id          = db.Column(db.Integer, primary_key=True)
    nome        = db.Column(db.String(100), nullable=False)
    email       = db.Column(db.String(120), unique=True, nullable=False)
    senha_hash  = db.Column(db.String(200), nullable=False)
    perfil      = db.Column(db.String(20), default='operador')  # admin | gestor | operador
    ativo       = db.Column(db.Boolean, default=True)
    criado_em   = db.Column(db.DateTime, default=datetime.utcnow)
    ultimo_acesso = db.Column(db.DateTime)

    consultas   = db.relationship('Consulta', backref='usuario', lazy=True)

    @property
    def is_admin(self):
        return self.perfil == 'admin'

    @property
    def is_gestor(self):
        return self.perfil in ('admin', 'gestor')


class Empresa(db.Model):
    __tablename__ = 'empresas'
    id          = db.Column(db.Integer, primary_key=True)
    cnpj        = db.Column(db.String(14), unique=True, nullable=False)
    nome        = db.Column(db.String(150), nullable=False)
    regime      = db.Column(db.String(20), default='lucro')  # simples | lucro | mei
    ativa       = db.Column(db.Boolean, default=True)
    criado_em   = db.Column(db.DateTime, default=datetime.utcnow)

    obrigacoes  = db.relationship('StatusObrigacao', backref='empresa', lazy=True,
                                   cascade='all, delete-orphan')

    @property
    def cnpj_formatado(self):
        c = self.cnpj.zfill(14)
        return f"{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}"


class Consulta(db.Model):
    __tablename__ = 'consultas'
    id          = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'))
    servicos    = db.Column(db.String(200))   # json list
    empresas    = db.Column(db.Text)           # json list de CNPJs
    status      = db.Column(db.String(20), default='pendente')  # pendente | rodando | concluida | erro
    iniciada_em = db.Column(db.DateTime, default=datetime.utcnow)
    concluida_em = db.Column(db.DateTime)
    log         = db.Column(db.Text, default='')
    resultados  = db.Column(db.Text, default='{}')  # JSON
    erros       = db.Column(db.Integer, default=0)
    sucessos    = db.Column(db.Integer, default=0)


class StatusObrigacao(db.Model):
    __tablename__ = 'status_obrigacoes'
    id          = db.Column(db.Integer, primary_key=True)
    empresa_id  = db.Column(db.Integer, db.ForeignKey('empresas.id'))
    servico     = db.Column(db.String(50))   # sitfis | dctfweb | pgdas | mit | caixa | parcelamento
    periodo     = db.Column(db.String(10))   # MM/YYYY
    status      = db.Column(db.String(20))   # ok | pendente | erro | nao_aplicavel
    detalhe     = db.Column(db.String(300))
    arquivo_pdf = db.Column(db.String(300))
    atualizado_em = db.Column(db.DateTime, default=datetime.utcnow)
    consulta_id = db.Column(db.Integer, db.ForeignKey('consultas.id'))


class Alerta(db.Model):
    __tablename__ = 'alertas'
    id          = db.Column(db.Integer, primary_key=True)
    empresa_id  = db.Column(db.Integer, db.ForeignKey('empresas.id'))
    tipo        = db.Column(db.String(50))    # pendencia | irregularidade | parcelamento
    mensagem    = db.Column(db.String(300))
    lido        = db.Column(db.Boolean, default=False)
    criado_em   = db.Column(db.DateTime, default=datetime.utcnow)
    empresa     = db.relationship('Empresa')


class Config(db.Model):
    __tablename__ = 'configs'
    id            = db.Column(db.Integer, primary_key=True)
    chave         = db.Column(db.String(50), unique=True)
    valor         = db.Column(db.Text)

    @staticmethod
    def get(chave, padrao=''):
        c = Config.query.filter_by(chave=chave).first()
        return c.valor if c else padrao

    @staticmethod
    def set(chave, valor):
        c = Config.query.filter_by(chave=chave).first()
        if c:
            c.valor = str(valor)
        else:
            db.session.add(Config(chave=chave, valor=str(valor)))
        db.session.commit()
