from flask import Blueprint, render_template, request, jsonify, redirect, url_for
from flask_login import login_required, current_user
from datetime import datetime
import json, threading
from ..models import Empresa, Consulta, StatusObrigacao, Alerta, db
from .. import socketio

bp = Blueprint('consultas', __name__)

SERVICOS_DISPONIVEIS = [
    {'id': 'sitfis',       'nome': 'Diagnóstico Fiscal (SITFIS)',    'grupo': 'RFB'},
    {'id': 'caixa',        'nome': 'Caixa Postal RFB',               'grupo': 'RFB'},
    {'id': 'caixa_nao_lidas','nome': 'Caixa Postal - PDF não lidas', 'grupo': 'RFB'},
    {'id': 'dctfweb',      'nome': 'DCTFWeb',                        'grupo': 'Declarações'},
    {'id': 'mit',          'nome': 'MIT - Módulo de Inclusão',       'grupo': 'Declarações'},
    {'id': 'simples',      'nome': 'PGDAS-D (Simples Nacional)',     'grupo': 'Declarações'},
    {'id': 'parcelamento', 'nome': 'Parcelamentos Ativos',           'grupo': 'Débitos'},
]


@bp.route('/consultas')
@login_required
def index():
    empresas = Empresa.query.filter_by(ativa=True).order_by(Empresa.nome).all()
    mes_atual = datetime.now().strftime('%m')
    ano_atual = datetime.now().strftime('%Y')
    return render_template('consultas/index.html',
        empresas=empresas,
        servicos=SERVICOS_DISPONIVEIS,
        mes_atual=mes_atual,
        ano_atual=ano_atual,
    )


@bp.route('/consultas/iniciar', methods=['POST'])
@login_required
def iniciar():
    data = request.json or {}
    servicos_sel  = data.get('servicos', [])
    empresas_sel  = data.get('empresas', [])
    dctf_mes      = data.get('dctf_mes', datetime.now().strftime('%m'))
    dctf_ano      = data.get('dctf_ano', datetime.now().strftime('%Y'))
    simples_mes   = data.get('simples_mes', dctf_mes)
    simples_ano   = data.get('simples_ano', dctf_ano)

    if not servicos_sel or not empresas_sel:
        return jsonify({'erro': 'Selecione ao menos um serviço e uma empresa.'}), 400

    consulta = Consulta(
        user_id   = current_user.id,
        servicos  = json.dumps(servicos_sel),
        empresas  = json.dumps(empresas_sel),
        status    = 'pendente',
    )
    db.session.add(consulta)
    db.session.commit()

    # Roda em thread separada
    thread = threading.Thread(
        target=_executar_consulta,
        args=(consulta.id, servicos_sel, empresas_sel,
              dctf_mes, dctf_ano, simples_mes, simples_ano),
        daemon=True
    )
    thread.start()

    return jsonify({'consulta_id': consulta.id})


@bp.route('/consultas/<int:cid>/status')
@login_required
def status(cid):
    c = Consulta.query.get_or_404(cid)
    return jsonify({
        'status':   c.status,
        'log':      c.log[-3000:] if c.log else '',
        'sucessos': c.sucessos,
        'erros':    c.erros,
        'concluida_em': c.concluida_em.isoformat() if c.concluida_em else None,
    })


@bp.route('/consultas/historico')
@login_required
def historico():
    page = request.args.get('page', 1, type=int)
    q = Consulta.query.order_by(Consulta.iniciada_em.desc())
    if not current_user.is_gestor:
        q = q.filter_by(user_id=current_user.id)
    consultas = q.paginate(page=page, per_page=20)
    return render_template('consultas/historico.html', consultas=consultas)


@bp.route('/consultas/<int:cid>/resultado')
@login_required
def resultado(cid):
    c = Consulta.query.get_or_404(cid)
    try:
        resultados = json.loads(c.resultados or '{}')
    except Exception:
        resultados = {}
    return render_template('consultas/resultado.html', consulta=c, resultados=resultados)


# ── Execução em background ────────────────────────────────────────────────────

def _executar_consulta(consulta_id, servicos, cnpjs, dctf_mes, dctf_ano,
                        simples_mes, simples_ano):
    from .. import create_app
    app = create_app()
    with app.app_context():
        consulta = Consulta.query.get(consulta_id)
        if not consulta:
            return

        consulta.status = 'rodando'
        db.session.commit()

        def emit_log(msg):
            consulta.log = (consulta.log or '') + msg + '\n'
            db.session.commit()
            socketio.emit('log', {'cid': consulta_id, 'msg': msg})

        try:
            from ...integra_contador.modules.autenticacao import SerproAuth
            from ...integra_contador.modules.cliente_api import ClienteIntegra
            from ...integra_contador.modules.servicos import (
                consultar_diagnostico_fiscal, listar_mensagens_caixa_postal,
                ler_mensagens_nao_lidas_pdf
            )
            from ...integra_contador.modules.servicos_dctfweb import (
                consultar_situacao_dctfweb, consultar_mit
            )
            from ...integra_contador.modules.servicos_simples import consultar_declaracoes_pgdas
            from ...integra_contador.modules.servicos_parcelamento import consultar_parcelamentos

            from ..models import Config
            ck     = Config.get('consumer_key')
            cs     = Config.get('consumer_secret')
            cert   = Config.get('cert_path')
            senha  = Config.get('cert_senha')
            cnpj_esc = Config.get('cnpj_escritorio')

            auth = SerproAuth(ck, cs, cert, senha, cnpj_esc)
            cliente = ClienteIntegra(auth,
                'https://gateway.apiserpro.serpro.gov.br/integra-contador/v1')

            empresas = Empresa.query.filter(
                Empresa.cnpj.in_(cnpjs), Empresa.ativa == True).all()

            resultados_todos = {}
            sucessos = 0
            erros    = 0

            for emp in empresas:
                emit_log(f"[{emp.nome}] Iniciando...")
                res_emp = {}

                _run_servico('sitfis', servicos, res_emp, emit_log, emp,
                    lambda: consultar_diagnostico_fiscal(
                        cliente, cnpj_esc, emp.cnpj, 2, '', 'relatorios'))

                _run_servico('caixa', servicos, res_emp, emit_log, emp,
                    lambda: listar_mensagens_caixa_postal(
                        cliente, cnpj_esc, emp.cnpj, 2))

                _run_servico('dctfweb', servicos, res_emp, emit_log, emp,
                    lambda: consultar_situacao_dctfweb(
                        cliente, cnpj_esc, emp.cnpj, 2, dctf_ano, dctf_mes))

                _run_servico('mit', servicos, res_emp, emit_log, emp,
                    lambda: consultar_mit(
                        cliente, cnpj_esc, emp.cnpj, 2, dctf_ano, dctf_mes))

                _run_servico('simples', servicos, res_emp, emit_log, emp,
                    lambda: consultar_declaracoes_pgdas(
                        cliente, cnpj_esc, emp.cnpj, 2, simples_ano, simples_mes))

                _run_servico('parcelamento', servicos, res_emp, emit_log, emp,
                    lambda: consultar_parcelamentos(
                        cliente, cnpj_esc, emp.cnpj, 2))

                # Salva status no banco
                _salvar_status(emp, res_emp, dctf_mes, dctf_ano, consulta_id)
                _gerar_alertas(emp, res_emp, dctf_mes, dctf_ano)

                resultados_todos[emp.cnpj] = res_emp
                if any(r.get('sucesso') for r in res_emp.values()):
                    sucessos += 1
                else:
                    erros += 1

                emit_log(f"[{emp.nome}] Concluido.")

            import json as _json
            consulta.resultados  = _json.dumps(resultados_todos, default=str)
            consulta.status      = 'concluida'
            consulta.concluida_em = datetime.utcnow()
            consulta.sucessos    = sucessos
            consulta.erros       = erros
            db.session.commit()
            socketio.emit('concluida', {'cid': consulta_id, 'sucessos': sucessos, 'erros': erros})

        except Exception as e:
            consulta.status = 'erro'
            consulta.log    = (consulta.log or '') + f'\nERRO CRITICO: {e}'
            db.session.commit()
            socketio.emit('erro', {'cid': consulta_id, 'msg': str(e)})


def _run_servico(srv_id, servicos_sel, res, emit_log, emp, fn):
    if srv_id not in servicos_sel:
        return
    try:
        emit_log(f"  [{emp.nome}] {srv_id}...")
        res[srv_id] = fn()
    except Exception as e:
        res[srv_id] = {'sucesso': False, 'erro': str(e)}
        emit_log(f"  [{emp.nome}] {srv_id} ERRO: {e}")


def _salvar_status(emp, res_emp, mes, ano, consulta_id):
    periodo = f"{mes}/{ano}"
    mapa = {
        'sitfis':      ('sitfis', lambda r: r.get('sucesso'), lambda r: 'ok' if r.get('sucesso') else 'pendente'),
        'caixa':       ('caixa', lambda r: r.get('sucesso'), lambda r: 'ok'),
        'dctfweb':     ('dctfweb', lambda r: r.get('transmitida'), lambda r: 'ok' if r.get('transmitida') else 'pendente'),
        'mit':         ('mit', lambda r: r.get('transmitida'), lambda r: 'ok' if r.get('transmitida') else 'pendente'),
        'simples':     ('pgdas', lambda r: r.get('transmitida'), lambda r: 'ok' if r.get('transmitida') else ('nao_aplicavel' if r.get('nao_simples') else 'pendente')),
        'parcelamento':('parcelamento', lambda r: True, lambda r: 'erro' if r.get('tem_parcelamento') else 'ok'),
    }
    for srv_id, (srv_nome, _, get_status) in mapa.items():
        r = res_emp.get(srv_id)
        if not r:
            continue
        st = get_status(r)
        det = r.get('situacao') or r.get('status') or r.get('erro', '')[:100]
        pdf = r.get('arquivo_pdf', '')

        obs = StatusObrigacao.query.filter_by(
            empresa_id=emp.id, servico=srv_nome, periodo=periodo).first()
        if not obs:
            obs = StatusObrigacao(empresa_id=emp.id, servico=srv_nome, periodo=periodo)
            db.session.add(obs)
        obs.status      = st
        obs.detalhe     = str(det)[:300]
        obs.arquivo_pdf = str(pdf)[:300]
        obs.atualizado_em = datetime.utcnow()
        obs.consulta_id = consulta_id
    db.session.commit()


def _gerar_alertas(emp, res_emp, mes, ano):
    periodo = f"{mes}/{ano}"
    for srv_id, srv_nome in [('dctfweb','DCTFWeb'), ('simples','PGDAS-D'), ('mit','MIT')]:
        r = res_emp.get(srv_id, {})
        if r.get('sucesso') and not r.get('transmitida') and not r.get('nao_simples'):
            msg = f"{srv_nome} não transmitida - período {periodo}"
            existe = Alerta.query.filter_by(
                empresa_id=emp.id, tipo='pendencia', mensagem=msg, lido=False).first()
            if not existe:
                db.session.add(Alerta(
                    empresa_id=emp.id, tipo='pendencia', mensagem=msg))

    r_sitfis = res_emp.get('sitfis', {})
    if r_sitfis.get('possui_debito'):
        msg = f"Débito em aberto identificado no SITFIS"
        existe = Alerta.query.filter_by(
            empresa_id=emp.id, tipo='irregularidade', mensagem=msg, lido=False).first()
        if not existe:
            db.session.add(Alerta(
                empresa_id=emp.id, tipo='irregularidade', mensagem=msg))

    r_parc = res_emp.get('parcelamento', {})
    if r_parc.get('tem_parcelamento'):
        n   = r_parc.get('total', 0)
        msg = f"{n} parcelamento(s) ativo(s)"
        existe = Alerta.query.filter_by(
            empresa_id=emp.id, tipo='parcelamento', mensagem=msg, lido=False).first()
        if not existe:
            db.session.add(Alerta(
                empresa_id=emp.id, tipo='parcelamento', mensagem=msg))

    db.session.commit()
