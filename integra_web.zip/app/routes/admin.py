from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from functools import wraps
from ..models import User, Empresa, Alerta, Config, db
from .. import bcrypt

bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_gestor:
            flash('Acesso restrito.', 'danger')
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated


# ── Usuários ──────────────────────────────────────────────────────────────────

@bp.route('/usuarios')
@login_required
@admin_required
def usuarios():
    users = User.query.order_by(User.nome).all()
    return render_template('admin/usuarios.html', users=users)


@bp.route('/usuarios/novo', methods=['GET', 'POST'])
@login_required
@admin_required
def novo_usuario():
    if request.method == 'POST':
        nome   = request.form['nome'].strip()
        email  = request.form['email'].strip().lower()
        senha  = request.form['senha']
        perfil = request.form['perfil']

        if User.query.filter_by(email=email).first():
            flash('Email já cadastrado.', 'danger')
            return redirect(url_for('admin.novo_usuario'))

        u = User(
            nome=nome, email=email,
            senha_hash=bcrypt.generate_password_hash(senha).decode('utf-8'),
            perfil=perfil, ativo=True
        )
        db.session.add(u)
        db.session.commit()
        flash(f'Usuário {nome} criado com sucesso.', 'success')
        return redirect(url_for('admin.usuarios'))

    return render_template('admin/form_usuario.html', usuario=None)


@bp.route('/usuarios/<int:uid>/editar', methods=['GET', 'POST'])
@login_required
@admin_required
def editar_usuario(uid):
    u = User.query.get_or_404(uid)
    if request.method == 'POST':
        u.nome   = request.form['nome'].strip()
        u.perfil = request.form['perfil']
        u.ativo  = request.form.get('ativo') == 'on'
        nova_senha = request.form.get('nova_senha', '').strip()
        if nova_senha:
            u.senha_hash = bcrypt.generate_password_hash(nova_senha).decode('utf-8')
        db.session.commit()
        flash('Usuário atualizado.', 'success')
        return redirect(url_for('admin.usuarios'))
    return render_template('admin/form_usuario.html', usuario=u)


@bp.route('/usuarios/<int:uid>/toggle')
@login_required
@admin_required
def toggle_usuario(uid):
    u = User.query.get_or_404(uid)
    u.ativo = not u.ativo
    db.session.commit()
    return jsonify({'ativo': u.ativo})


# ── Empresas ──────────────────────────────────────────────────────────────────

@bp.route('/empresas')
@login_required
@admin_required
def empresas():
    emps = Empresa.query.order_by(Empresa.nome).all()
    return render_template('admin/empresas.html', empresas=emps)


@bp.route('/empresas/nova', methods=['POST'])
@login_required
@admin_required
def nova_empresa():
    cnpj   = request.form['cnpj'].replace('.','').replace('/','').replace('-','')
    nome   = request.form['nome'].strip()
    regime = request.form.get('regime', 'lucro')

    if Empresa.query.filter_by(cnpj=cnpj).first():
        flash('CNPJ já cadastrado.', 'danger')
        return redirect(url_for('admin.empresas'))

    db.session.add(Empresa(cnpj=cnpj, nome=nome, regime=regime))
    db.session.commit()
    flash(f'{nome} cadastrada.', 'success')
    return redirect(url_for('admin.empresas'))


@bp.route('/empresas/importar', methods=['POST'])
@login_required
@admin_required
def importar_empresas():
    texto = request.form.get('lista', '')
    adicionadas = 0
    for linha in texto.strip().splitlines():
        partes = linha.strip().split(None, 1)
        if not partes:
            continue
        cnpj = partes[0].replace('.','').replace('/','').replace('-','')
        if not cnpj.isdigit() or len(cnpj) not in (11, 14):
            continue
        nome = partes[1].strip() if len(partes) > 1 else cnpj
        if not Empresa.query.filter_by(cnpj=cnpj).first():
            db.session.add(Empresa(cnpj=cnpj, nome=nome))
            adicionadas += 1
    db.session.commit()
    flash(f'{adicionadas} empresa(s) importada(s).', 'success')
    return redirect(url_for('admin.empresas'))


@bp.route('/empresas/<int:eid>/toggle')
@login_required
@admin_required
def toggle_empresa(eid):
    e = Empresa.query.get_or_404(eid)
    e.ativa = not e.ativa
    db.session.commit()
    return jsonify({'ativa': e.ativa})


# ── Configurações ─────────────────────────────────────────────────────────────

@bp.route('/configuracoes', methods=['GET', 'POST'])
@login_required
@admin_required
def configuracoes():
    if request.method == 'POST':
        campos = ['consumer_key','consumer_secret','cert_path','cert_senha',
                  'cnpj_escritorio','nome_escritorio','mail_server',
                  'mail_port','mail_user','mail_pass','whatsapp_token','whatsapp_numero']
        for campo in campos:
            val = request.form.get(campo, '').strip()
            if val:
                Config.set(campo, val)
        flash('Configurações salvas.', 'success')
        return redirect(url_for('admin.configuracoes'))

    cfg = {c.chave: c.valor for c in Config.query.all()}
    return render_template('admin/configuracoes.html', cfg=cfg)


# ── Alertas ───────────────────────────────────────────────────────────────────

@bp.route('/alertas')
@login_required
def alertas():
    page = request.args.get('page', 1, type=int)
    alertas = Alerta.query.order_by(Alerta.criado_em.desc()).paginate(page=page, per_page=30)
    return render_template('admin/alertas.html', alertas=alertas)


@bp.route('/alertas/<int:aid>/ler')
@login_required
def marcar_lido(aid):
    a = Alerta.query.get_or_404(aid)
    a.lido = True
    db.session.commit()
    return jsonify({'ok': True})


@bp.route('/alertas/ler-todos')
@login_required
def marcar_todos_lidos():
    Alerta.query.filter_by(lido=False).update({'lido': True})
    db.session.commit()
    flash('Todos os alertas marcados como lidos.', 'success')
    return redirect(url_for('admin.alertas'))
