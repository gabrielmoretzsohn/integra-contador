from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from ..models import Empresa, StatusObrigacao, Consulta, Alerta, db
from sqlalchemy import func

bp = Blueprint('dashboard', __name__)


@bp.route('/dashboard')
@login_required
def index():
    periodo_atual = datetime.now().strftime('%m/%Y')
    periodo_anterior = (datetime.now().replace(day=1) - timedelta(days=1)).strftime('%m/%Y')

    total_empresas = Empresa.query.filter_by(ativa=True).count()

    # Status do periodo atual
    status_atual = _calc_status_periodo(periodo_atual)
    status_anterior = _calc_status_periodo(periodo_anterior)

    # Alertas nao lidos
    alertas = Alerta.query.filter_by(lido=False)\
                    .order_by(Alerta.criado_em.desc()).limit(10).all()

    # Ultimas consultas
    consultas = Consulta.query.order_by(Consulta.iniciada_em.desc()).limit(5).all()

    # Grafico: status por servico no periodo atual
    servicos = ['sitfis', 'dctfweb', 'mit', 'pgdas', 'caixa', 'parcelamento']
    grafico = {}
    for srv in servicos:
        ok  = StatusObrigacao.query.filter_by(servico=srv, periodo=periodo_atual, status='ok').count()
        pend = StatusObrigacao.query.filter_by(servico=srv, periodo=periodo_atual, status='pendente').count()
        erro = StatusObrigacao.query.filter_by(servico=srv, periodo=periodo_atual, status='erro').count()
        if ok + pend + erro > 0:
            grafico[srv] = {'ok': ok, 'pendente': pend, 'erro': erro}

    return render_template('dashboard/index.html',
        total_empresas=total_empresas,
        status_atual=status_atual,
        status_anterior=status_anterior,
        periodo_atual=periodo_atual,
        periodo_anterior=periodo_anterior,
        alertas=alertas,
        consultas=consultas,
        grafico=grafico,
    )


@bp.route('/dashboard/tempo-real')
@login_required
def tempo_real():
    periodo = datetime.now().strftime('%m/%Y')
    empresas = Empresa.query.filter_by(ativa=True).order_by(Empresa.nome).all()

    dados = []
    for emp in empresas:
        obrigacoes = {}
        for obs in StatusObrigacao.query.filter_by(empresa_id=emp.id, periodo=periodo).all():
            obrigacoes[obs.servico] = {
                'status':  obs.status,
                'detalhe': obs.detalhe,
                'pdf':     obs.arquivo_pdf,
                'atualizado': obs.atualizado_em.strftime('%d/%m %H:%M') if obs.atualizado_em else ''
            }
        dados.append({'empresa': emp, 'obrigacoes': obrigacoes})

    alertas_count = Alerta.query.filter_by(lido=False).count()
    return render_template('dashboard/tempo_real.html',
        dados=dados, periodo=periodo, alertas_count=alertas_count)


@bp.route('/api/dashboard/resumo')
@login_required
def api_resumo():
    periodo = datetime.now().strftime('%m/%Y')
    status = _calc_status_periodo(periodo)
    alertas = Alerta.query.filter_by(lido=False).count()
    return jsonify({**status, 'alertas': alertas, 'periodo': periodo})


def _calc_status_periodo(periodo):
    total = Empresa.query.filter_by(ativa=True).count()
    ok    = db.session.query(func.count(func.distinct(StatusObrigacao.empresa_id)))\
                      .filter(StatusObrigacao.periodo == periodo,
                              StatusObrigacao.status == 'ok').scalar() or 0
    pend  = db.session.query(func.count(func.distinct(StatusObrigacao.empresa_id)))\
                      .filter(StatusObrigacao.periodo == periodo,
                              StatusObrigacao.status == 'pendente').scalar() or 0
    return {'total': total, 'ok': ok, 'pendente': pend,
            'nao_consultado': max(0, total - ok - pend)}
