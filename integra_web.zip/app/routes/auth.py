from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
from .. import db, bcrypt
from ..models import User

bp = Blueprint('auth', __name__)


@bp.route('/', methods=['GET', 'POST'])
@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        senha = request.form.get('senha', '')
        lembrar = request.form.get('lembrar') == 'on'

        user = User.query.filter_by(email=email).first()
        if user and user.ativo and bcrypt.check_password_hash(user.senha_hash, senha):
            login_user(user, remember=lembrar)
            user.ultimo_acesso = datetime.utcnow()
            db.session.commit()
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard.index'))
        flash('Email ou senha incorretos.', 'danger')

    return render_template('auth/login.html')


@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))


@bp.route('/perfil', methods=['GET', 'POST'])
@login_required
def perfil():
    if request.method == 'POST':
        nome = request.form.get('nome', '').strip()
        senha_atual = request.form.get('senha_atual', '')
        nova_senha  = request.form.get('nova_senha', '')

        if nome:
            current_user.nome = nome

        if senha_atual and nova_senha:
            if bcrypt.check_password_hash(current_user.senha_hash, senha_atual):
                current_user.senha_hash = bcrypt.generate_password_hash(nova_senha).decode('utf-8')
                flash('Senha alterada com sucesso.', 'success')
            else:
                flash('Senha atual incorreta.', 'danger')
                return redirect(url_for('auth.perfil'))

        db.session.commit()
        flash('Perfil atualizado.', 'success')
        return redirect(url_for('auth.perfil'))

    return render_template('auth/perfil.html')
