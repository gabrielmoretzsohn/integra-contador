from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from datetime import datetime
from ..models import StatusObrigacao, Empresa, Alerta, Consulta, db

bp = Blueprint('api', __name__, url_prefix='/api')


@bp.route('/status-empresas')
@login_required
def status_empresas():
    periodo = request.args.get('periodo', datetime.now().strftime('%m/%Y'))
    empresas = Empresa.query.filter_by(ativa=True).order_by(Empresa.nome).all()

    resultado = []
    for emp in empresas:
        obs_dict = {}
        for obs in StatusObrigacao.query.filter_by(empresa_id=emp.id, periodo=periodo):
            obs_dict[obs.servico] = {
                'status':     obs.status,
                'detalhe':    obs.detalhe,
                'atualizado': obs.atualizado_em.strftime('%d/%m %H:%M') if obs.atualizado_em else '-'
            }
        resultado.append({
            'id':          emp.id,
            'cnpj':        emp.cnpj_formatado,
            'nome':        emp.nome,
            'regime':      emp.regime,
            'obrigacoes':  obs_dict,
        })
    return jsonify(resultado)


@bp.route('/alertas/nao-lidos')
@login_required
def alertas_nao_lidos():
    alertas = Alerta.query.filter_by(lido=False)\
                    .order_by(Alerta.criado_em.desc()).limit(20).all()
    return jsonify([{
        'id':       a.id,
        'empresa':  a.empresa.nome if a.empresa else '',
        'tipo':     a.tipo,
        'mensagem': a.mensagem,
        'criado':   a.criado_em.strftime('%d/%m %H:%M'),
    } for a in alertas])


@bp.route('/consulta/<int:cid>/progresso')
@login_required
def progresso(cid):
    c = Consulta.query.get_or_404(cid)
    return jsonify({
        'status':     c.status,
        'log':        (c.log or '')[-2000:],
        'sucessos':   c.sucessos,
        'erros':      c.erros,
        'concluida':  c.concluida_em.isoformat() if c.concluida_em else None,
    })
