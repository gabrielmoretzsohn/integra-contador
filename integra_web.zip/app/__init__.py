from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_mail import Mail
from flask_socketio import SocketIO
import os

db        = SQLAlchemy()
login_mgr = LoginManager()
bcrypt    = Bcrypt()
mail      = Mail()
socketio  = SocketIO()

def create_app():
    app = Flask(__name__, template_folder='../templates', static_folder='../static')

    app.config['SECRET_KEY']           = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-prod')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///integra.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Email
    app.config['MAIL_SERVER']   = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    app.config['MAIL_PORT']     = int(os.environ.get('MAIL_PORT', 587))
    app.config['MAIL_USE_TLS']  = True
    app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', '')
    app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', '')
    app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('MAIL_USERNAME', '')

    db.init_app(app)
    bcrypt.init_app(app)
    mail.init_app(app)
    socketio.init_app(app, cors_allowed_origins="*", async_mode='eventlet')

    login_mgr.init_app(app)
    login_mgr.login_view = 'auth.login'
    login_mgr.login_message = 'Faça login para acessar.'

    from .models import User
    @login_mgr.user_loader
    def load_user(uid):
        return User.query.get(int(uid))

    # Blueprints
    from .routes.auth    import bp as auth_bp
    from .routes.dashboard import bp as dash_bp
    from .routes.consultas import bp as cons_bp
    from .routes.admin   import bp as admin_bp
    from .routes.api     import bp as api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dash_bp)
    app.register_blueprint(cons_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(api_bp)

    # Filtro Jinja2 para parsear JSON em templates
    import json
    app.jinja_env.filters['fromjson'] = lambda s: json.loads(s) if s else []

    with app.app_context():
        db.create_all()
        _seed_admin()

    return app


def _seed_admin():
    from .models import User
    if not User.query.filter_by(email='admin@escritorio.com').first():
        from . import bcrypt
        u = User(
            nome='Administrador',
            email='admin@escritorio.com',
            senha_hash=bcrypt.generate_password_hash('admin123').decode('utf-8'),
            perfil='admin',
            ativo=True
        )
        db.session.add(u)
        db.session.commit()
