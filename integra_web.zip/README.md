# Integra Contador — Painel Web

Sistema web para monitoramento fiscal da equipe contábil.

## Funcionalidades
- Login com perfis: Admin / Gestor / Operador
- Dashboard com status em tempo real de todas as empresas
- Execução de consultas diretamente pelo navegador
- Histórico de consultas e relatórios
- Alertas automáticos de pendências
- Controle de acesso por usuário
- WebSocket para progresso em tempo real

## Instalação Local

```bash
cd integra_web
pip install -r requirements.txt
cp .env.example .env
# Edite .env com suas configurações
python run.py
# Acesse: http://localhost:5000
# Login padrão: admin@escritorio.com / admin123
```

## Deploy no Railway (Recomendado)

1. Crie conta em https://railway.app
2. Crie novo projeto → Deploy from GitHub
3. Adicione as variáveis de ambiente (.env)
4. Railway detecta automaticamente o Python e faz deploy
5. Adicione o plugin PostgreSQL (gratuito até 500MB)
6. Mude DATABASE_URL para a URL do PostgreSQL fornecida

**Custo estimado: R$ 25-60/mês para 20+ usuários**

## Deploy no DigitalOcean (Alternativa robusta)

```bash
# Na VPS Ubuntu:
git clone seu-repositorio
cd integra_web
pip install -r requirements.txt
# Configure .env
# Instale nginx e certbot para HTTPS
gunicorn -w 4 -k eventlet run:app --bind 0.0.0.0:5000
```

## Perfis de Acesso

| Perfil   | Pode fazer                                    |
|----------|-----------------------------------------------|
| admin    | Tudo + gerenciar usuários e configurações      |
| gestor   | Consultas + ver todos os resultados + alertas  |
| operador | Apenas consultas e ver próprio histórico       |

## Credenciais Padrão
- Email: admin@escritorio.com
- Senha: admin123
- **TROQUE a senha no primeiro acesso!**
